
public class string {

}
