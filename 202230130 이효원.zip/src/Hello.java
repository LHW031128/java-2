public class Hello {
    public class InnerHello {
        public static void main(String[] args) {
            System.out.println("InnerHllo");
        }
    }
    public static void main(String[]arhs) {
        System.out.println("Hello");
    }
}
