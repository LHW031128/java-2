public class Bar {

    public static void main(string[] args){
    final double PI = 3.14;
    double radius = 10.2;
    double circleArea = radius*radius*PI;

    System.out.print("반지름" + radius + ".");
    System.out.println("원의 면석 = "+circleArea);
    }
}
